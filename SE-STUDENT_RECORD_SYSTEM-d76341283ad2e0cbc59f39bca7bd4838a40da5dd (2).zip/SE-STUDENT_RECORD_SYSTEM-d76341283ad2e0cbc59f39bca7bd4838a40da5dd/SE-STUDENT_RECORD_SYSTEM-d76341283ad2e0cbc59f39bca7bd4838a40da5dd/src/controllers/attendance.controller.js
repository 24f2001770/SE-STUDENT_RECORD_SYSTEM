
const pool = require('../config/db');

const validDate = (value) => {
  if (typeof value !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const date = new Date(`${value}T00:00:00Z`);

  return !Number.isNaN(date.getTime()) &&
    date.toISOString().slice(0, 10) === value;
};

// POST /api/attendance
// Body: { courseId, date, records: [{ studentId, status }] }
exports.recordAttendance = async (req, res, next) => {
  const { courseId, date, records } = req.body || {};

  const course = Number(courseId);

  if (!Number.isSafeInteger(course) || course <= 0) {
    return res.status(400).json({
      error: 'A valid courseId is required.',
    });
  }

  if (!validDate(date)) {
    return res.status(400).json({
      error: 'Date must use YYYY-MM-DD format.',
    });
  }

  if (date > new Date().toISOString().slice(0, 10)) {
    return res.status(400).json({
      error: 'Future attendance dates are not allowed.',
    });
  }

  if (!Array.isArray(records) || records.length === 0) {
    return res.status(400).json({
      error: 'At least one attendance record is required.',
    });
  }

  const seen = new Set();

  for (const record of records) {
    if (!record || typeof record.studentId !== 'string' ||
        !record.studentId.trim()) {
      return res.status(400).json({
        error: 'Every record needs a valid studentId.',
      });
    }

    if (!['PRESENT', 'ABSENT'].includes(record.status)) {
      return res.status(400).json({
        error: 'Status must be PRESENT or ABSENT.',
      });
    }

    if (seen.has(record.studentId)) {
      return res.status(400).json({
        error: `Duplicate studentId: ${record.studentId}`,
      });
    }

    seen.add(record.studentId);
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // Verify the course exists and the faculty member is assigned.
    const [courses] = await connection.execute(
      `SELECT course_id, faculty_user_id
       FROM courses
       WHERE course_id = ?`,
      [course]
    );

    if (!courses.length) {
      await connection.rollback();
      return res.status(404).json({
        error: 'Course not found.',
      });
    }

    // req.user must be populated by your authentication middleware.
    if (
      req.user?.role === 'FACULTY' &&
      String(courses[0].faculty_user_id) !== String(req.user.user_id)
    ) {
      await connection.rollback();
      return res.status(403).json({
        error: 'You are not assigned to this course.',
      });
    }

    if (!['ADMIN', 'FACULTY'].includes(req.user?.role)) {
      await connection.rollback();
      return res.status(403).json({
        error: 'Only faculty or admins can record attendance.',
      });
    }

    for (const record of records) {
      const [enrollments] = await connection.execute(
        `SELECT student_id
         FROM course_enrollments
         WHERE course_id = ? AND student_id = ?`,
        [course, record.studentId]
      );

      if (!enrollments.length) {
        await connection.rollback();
        return res.status(400).json({
          error: `Student ${record.studentId} is not enrolled in this course.`,
        });
      }

      await connection.execute(
        `INSERT INTO attendance
          (course_id, student_id, attendance_date, status, marked_by)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           status = VALUES(status),
           marked_by = VALUES(marked_by)`,
        [
          course,
          record.studentId,
          date,
          record.status,
          req.user.user_id,
        ]
      );
    }

    await connection.commit();

    return res.status(200).json({
      message: 'Attendance recorded successfully.',
      courseId: course,
      date,
      recordsSaved: records.length,
    });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
};

// GET /api/attendance/course/:courseId
exports.getCourseAttendance = async (req, res, next) => {
  try {
    const courseId = Number(req.params.courseId);

    if (!Number.isSafeInteger(courseId) || courseId <= 0) {
      return res.status(400).json({
        error: 'Invalid courseId.',
      });
    }

    const [courses] = await pool.execute(
      'SELECT course_id, faculty_user_id FROM courses WHERE course_id = ?',
      [courseId]
    );

    if (!courses.length) {
      return res.status(404).json({
        error: 'Course not found.',
      });
    }

    if (
      req.user?.role === 'FACULTY' &&
      String(courses[0].faculty_user_id) !== String(req.user.user_id)
    ) {
      return res.status(403).json({
        error: 'You are not assigned to this course.',
      });
    }

    if (!['ADMIN', 'FACULTY'].includes(req.user?.role)) {
      return res.status(403).json({
        error: 'Only faculty or admins can view course attendance.',
      });
    }

    const { date } = req.query;

    if (date && !validDate(date)) {
      return res.status(400).json({
        error: 'Date must use YYYY-MM-DD format.',
      });
    }

    let sql = `
      SELECT
        a.attendance_id,
        a.student_id,
        s.full_name,
        a.attendance_date,
        a.status
      FROM attendance a
      JOIN students s ON s.student_id = a.student_id
      WHERE a.course_id = ?
    `;

    const params = [courseId];

    if (date) {
      sql += ' AND a.attendance_date = ?';
      params.push(date);
    }

    sql += ' ORDER BY a.attendance_date DESC, s.full_name ASC';

    const [rows] = await pool.execute(sql, params);

    return res.json({
      courseId,
      count: rows.length,
      records: rows,
    });
  } catch (error) {
    next(error);
  }
};
