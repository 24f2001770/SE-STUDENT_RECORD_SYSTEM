
const express = require('express');
const {
  recordAttendance,
  getCourseAttendance,
} = require('../controllers/attendance.controller');

const { authenticate } = require('../middleware/auth.middleware');

const router = express.Router();

// Authenticate every attendance request before reaching its handler.
router.use(authenticate);

router.post('/', recordAttendance);
router.get('/course/:courseId', getCourseAttendance);

module.exports = router;
