# StudentHub — Student Record System

A Node.js + Express + MySQL application based on the supplied Student Record System SRS. It includes a responsive browser UI, role-based APIs, academic records, attendance, assessment/marks, reports and audit history.

## Technology
- Node.js 20+ / Express
- MySQL 8+ / mysql2
- HTML, CSS and browser JavaScript
- JWT authentication, bcrypt password hashing, Helmet and login rate limiting

## Run on Windows
1. Install Node.js 20+ and MySQL 8+.
2. Extract the ZIP. Open PowerShell in the `Student_Record_System_Complete` folder.
3. Install packages:
   ```powershell
   npm install
   ```
4. Create your local environment file:
   ```powershell
   Copy-Item .env.example .env
   ```
5. Edit `.env` and set your MySQL username/password and a private random `JWT_SECRET` of at least 32 characters. The default database name is `student_record_system_sprint`.
6. Open MySQL Workbench and execute these files in order:
   - `database/schema.sql`
   - `database/seed.sql`
7. Create local demo login accounts:
   ```powershell
   node scripts/create-demo-users.js
   ```
8. Start the server:
   ```powershell
   npm start
   ```
9. Open http://localhost:3000

## Local demo accounts
| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `AdminDemo@123` |
| Faculty | `faculty` | `FacultyDemo@123` |
| Student | `student001` | `StudentDemo@123` |

These are local demonstration credentials only. Change them before any shared or deployed use. Registration requires an active student row in the database. The seed data creates `STU001` and `STU002`.

## Included workflows
- Login, student registration, logout, JWT sessions and role-based access.
- Five-failure account lockout and login rate limiting.
- Admin student record creation and student search.
- Course catalogue, course creation, student enrollment and faculty-course assignment.
- Faculty attendance entry; student attendance view; low-attendance alerts.
- Assessment creation, marks entry/update, publication and student published-results view.
- Illustrative GPA/CGPA calculation on a 10-point scale.
- Summary reports, attendance CSV export, user activation/deactivation and audit log.

## Important API routes
- `POST /api/auth/login`, `POST /api/auth/register`, `POST /api/auth/logout`, `GET /api/auth/me`
- `GET /api/dashboard`
- `GET/POST /api/students`, `PATCH /api/students/:id`
- `GET/POST /api/courses`, `POST /api/enrollments`, `POST /api/assignments`
- `GET /api/attendance/me`, `GET /api/attendance/course/:id`, `POST /api/attendance`
- `POST /api/assessments`, `POST /api/marks`, `PATCH /api/assessments/:id/publish`
- `GET /api/marks/me`, `GET /api/marks/course/:id`, `GET /api/results/me`
- `GET /api/reports/summary`, `GET /api/reports/attendance.csv`, `GET /api/alerts/low-attendance`
- `GET /api/users`, `PATCH /api/users/:id/status`, `GET /api/audit`

Protected routes require `Authorization: Bearer <token>`.

## Testing
Run the automated checks:
```powershell
npm test
npm run check
```
`tests/grade.test.js` contains grade calculation tests. `TEST_PLAN.md` contains a manual functional, validation, authorization and security test checklist. Execute each test against your own MySQL setup and record actual results; this ZIP does not claim that live database/browser tests have already passed.

## Notes / limitations to resolve before production
- The CGPA mapping is explicitly illustrative; replace it with your institution's official grade-point and credit rules before treating it as an official result.
- HTTPS must be terminated at a trusted reverse proxy for network deployment. Localhost development uses HTTP.
- The demo seed data and credentials are for local testing only.
- Backups, restore drills, institutional grading policy, production secrets, HTTPS deployment, and load/performance testing must be configured and verified in the target environment.
- This is a course-project implementation, not a certified production student information system.
