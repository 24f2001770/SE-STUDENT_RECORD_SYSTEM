const mysql=require('mysql2/promise');
module.exports=mysql.createPool({host:process.env.DB_HOST||'localhost',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:process.env.DB_NAME||'student_record_system_sprint',waitForConnections:true,connectionLimit:10,decimalNumbers:true,dateStrings:true});
