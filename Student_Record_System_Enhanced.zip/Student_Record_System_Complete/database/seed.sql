USE student_record_system_sprint;
INSERT IGNORE INTO departments(department_name,department_code) VALUES('Computer Science','CSE'),('Information Science','ISE');
INSERT IGNORE INTO students(student_id,first_name,last_name,email,department_id,year_of_study) VALUES('STU001','Sample','Student','student@example.com',1,2),('STU002','Aarav','Shah','aarav@example.com',1,3);
INSERT IGNORE INTO faculty(faculty_id,first_name,last_name,email,department_id) VALUES('FAC001','Demo','Faculty','faculty@example.com',1);
INSERT IGNORE INTO courses(course_code,course_name,credits,department_id,semester) VALUES('CS101','Software Engineering',4,1,'Semester 1'),('CS102','Database Systems',4,1,'Semester 1');
INSERT IGNORE INTO course_assignments(course_id,faculty_id) SELECT course_id,'FAC001' FROM courses WHERE course_code IN('CS101','CS102');
INSERT IGNORE INTO course_enrollments(student_id,course_id,semester) SELECT 'STU001',course_id,'Semester 1' FROM courses;
