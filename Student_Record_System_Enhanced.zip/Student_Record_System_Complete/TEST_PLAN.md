# Student Record System — Test Plan and Test Cases

## Test setup
- Node.js 20+, MySQL 8+, database `student_record_system_sprint`.
- Run `database/schema.sql`, `database/seed.sql`, `node scripts/create-demo-users.js`, then `npm start`.
- Browser: `http://localhost:3000`.
- Demo accounts are listed in README.md.

## Test cases
| ID | Area | Test steps | Expected result |
|---|---|---|---|
| TC-AUTH-01 | Login | Login with valid admin credentials | Admin dashboard opens |
| TC-AUTH-02 | Login | Login with incorrect password | Login rejected with safe error |
| TC-AUTH-03 | Login | Submit empty username/password | Browser/server validation rejects request |
| TC-AUTH-04 | Lockout | Submit 5 consecutive incorrect passwords | Account is temporarily locked |
| TC-AUTH-05 | Logout | Click Log out, then revisit protected page | Session token cleared; login required |
| TC-AUTH-06 | Registration | Register with active seeded student ID | Student account created |
| TC-AUTH-07 | Registration | Register with unknown/inactive student ID | Registration rejected |
| TC-ROLE-01 | Authorization | Student attempts admin-only user API | HTTP 403 |
| TC-ROLE-02 | Authorization | Unauthenticated client requests protected API | HTTP 401 |
| TC-STU-01 | Student records | Admin creates a unique student ID | Student record saved |
| TC-STU-02 | Student records | Admin creates duplicate student ID | Duplicate rejected by database |
| TC-STU-03 | Search | Search by student ID or name | Matching students returned |
| TC-COURSE-01 | Courses | Admin creates a course with valid code/name/credits | Course appears in catalogue |
| TC-COURSE-02 | Courses | Create duplicate course code | Duplicate rejected |
| TC-COURSE-03 | Enrollment | Enroll existing student in course | Enrollment saved |
| TC-COURSE-04 | Assignment | Assign faculty to course | Faculty can see assigned course |
| TC-ATT-01 | Attendance | Assigned faculty records PRESENT attendance | Record saved |
| TC-ATT-02 | Attendance | Submit invalid attendance status | Request rejected |
| TC-ATT-03 | Attendance | Student views attendance | Only own attendance is returned |
| TC-ATT-04 | Attendance | Record repeated student/course/date | Duplicate attendance rejected or upsert behavior verified |
| TC-MARK-01 | Marks | Faculty creates assessment for assigned course | Assessment created |
| TC-MARK-02 | Marks | Enter marks within 0..maximum | Marks and grade saved |
| TC-MARK-03 | Marks | Enter marks greater than maximum or negative | Request rejected |
| TC-MARK-04 | Publication | Publish assessment | Student can view its marks |
| TC-MARK-05 | Publication | Unpublish assessment | Student no longer sees those marks |
| TC-RESULT-01 | Results | Student opens results | GPA/CGPA summary and course history shown |
| TC-REPORT-01 | Reports | Admin opens summary report | Student/attendance/marks aggregates shown |
| TC-REPORT-02 | Reports | Export attendance CSV | CSV downloads and contains attendance rows |
| TC-USER-01 | User management | Admin deactivates a user | User cannot authenticate |
| TC-AUDIT-01 | Audit | Perform login and academic updates | Audit events are recorded with timestamps |
| TC-SEC-01 | SQL injection | Submit SQL metacharacters in login/search fields | Input treated as data; no unauthorized query runs |
| TC-SEC-02 | Password storage | Inspect users.password_hash | Password is bcrypt hash, not plaintext |

## Execution record
For each test, record: date/time, tester, test ID, actual result, Pass/Fail/Blocked, screenshot or evidence, defect ID, and retest result. Do not mark a case Pass until it has been run against the application and database.

## Known environment-dependent checks
- NFR response-time targets (login under 3 seconds, search under 2 seconds, dashboards under 3 seconds, reports under 5 seconds) require measurement on the target machine and representative data.
- HTTPS, backup access restrictions and successful database restoration must be tested in the deployment environment; localhost alone cannot demonstrate these requirements.
